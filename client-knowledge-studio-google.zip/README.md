# Client Knowledge Studio

Standalone React application for demonstrating corporate client onboarding as a
knowledge graph. This edition has no dependency on ChatGPT, OpenAI Sites,
Cloudflare Workers, Vinext, D1, R2 or ChatGPT authentication.

## Technology

- React 19 and TypeScript
- Standard Vite build
- Cytoscape.js with the fCoSE force-directed layout
- Radix UI primitives
- Tailwind CSS processing
- In-memory demonstration data

## Run locally

Install Node.js 20.19 or later, then run:

```bash
npm ci
npm run dev
```

Open http://localhost:5173.

## Production build

```bash
npm run build
npm run preview
```

The deployable static output is created in `dist/`. The preview server is
available at http://localhost:4173.

## Import into Google Firebase Studio

1. Create a new workspace and import or upload this project.
2. Select Node.js/React when prompted for the environment.
3. Run `npm ci` in the workspace terminal.
4. Run `npm run dev` to continue development.
5. For deployment, use `npm run build`; publish the generated `dist` folder as a
   static web application.

If the Studio environment asks for framework settings, use:

- Framework: Vite / React
- Install command: `npm ci`
- Development command: `npm run dev`
- Build command: `npm run build`
- Output directory: `dist`

## Application flow

1. Use the prefilled demonstration login.
2. Open the Meridian Components case from the inbox.
3. Select onboarding stages to view their data.
4. Select **Client graph** at the top-right to open the full-screen fCoSE graph.

## Important

The login is a UI simulation. Add a real identity provider and backend
authorization before using the application with real client information.
