@echo off
setlocal
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js was not found. Install Node.js 22 LTS from https://nodejs.org/
  pause
  exit /b 1
)

echo Checking Node.js...
node --version

if not exist node_modules (
  echo Installing the locked dependencies. This can take several minutes...
  call npm ci
  if errorlevel 1 (
    echo Dependency installation failed. Review WINDOWS_SETUP.md.
    pause
    exit /b 1
  )
)

echo.
echo Client Knowledge Studio will be available at http://localhost:5173
echo Press Ctrl+C to stop the server.
echo.
call npm run dev

