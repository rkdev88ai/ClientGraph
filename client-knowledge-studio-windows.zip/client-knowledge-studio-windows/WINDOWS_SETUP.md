# Client Knowledge Studio — Windows Setup

This package contains the corporate client onboarding UI and interactive client
knowledge graph. It uses React, TypeScript, Node.js, Vinext/Vite, Cytoscape.js and
the `cytoscape-fcose` force-directed layout.

The application is a UI demonstration using in-memory sample data. No database,
API keys, Docker, Python, Java or WSL installation is required.

## Included features

- Login screen with prefilled demonstration credentials
- Client Manager inbox
- Meridian Components onboarding workspace
- Clickable onboarding journey and stage-level fields
- Client information drawer
- Full-screen client knowledge graph
- fCoSE force-directed layout, search, filters and relationship highlighting
- Exact dependency versions in `package-lock.json`
- Windows launch scripts for development and production-style local hosting

## Prerequisites

1. Windows 10 or Windows 11, 64-bit.
2. Node.js 22.13 or later. Install Node.js 22 LTS from https://nodejs.org/ and
   select the option that adds Node.js to PATH.
3. An internet connection for the first dependency installation.

## Quick start — recommended

1. Extract the ZIP to a short local path, for example:

   `C:\Projects\client-knowledge-studio`

2. Double-click `start-local.cmd`.
3. Wait for the terminal to show that the server is ready.
4. Open http://localhost:5173 in Chrome or Microsoft Edge.
5. Select **Sign in securely** using the prefilled credentials.
6. Open the **Meridian Components Pte. Ltd.** case.
7. Select **Client graph** at the top-right.

The first launch runs `npm ci` and can take several minutes. Subsequent launches
reuse the installed `node_modules` directory.

## PowerShell installation

Open PowerShell in the extracted project folder and run:

```powershell
node --version
npm --version
npm ci
npm run dev
```

Open http://localhost:5173. Keep the PowerShell window open while using the app.
Press `Ctrl+C` to stop the server.

## Production-style local hosting

Double-click `start-production.cmd`, or run:

```powershell
npm ci
npm run build
npm run start
```

Open the URL printed in the terminal. Vinext normally uses
http://localhost:3000 for its production server. Press `Ctrl+C` to stop it.

## Dependencies

All dependencies are declared in `package.json` and locked to reproducible
versions in `package-lock.json`. Use `npm ci` for setup. The ZIP intentionally
does not contain `node_modules`: native binaries installed on Linux are not
portable to Windows, and including them would make the package unreliable.

To rebuild dependencies from scratch:

```powershell
Remove-Item -Recurse -Force node_modules
npm ci
```

## Commands

| Command | Purpose |
|---|---|
| `npm ci` | Install the exact locked dependencies |
| `npm run dev` | Start development hosting on port 5173 |
| `npm run build` | Create an optimized build |
| `npm run start` | Host the optimized build locally |
| `npm run lint` | Run source-code checks |

## Troubleshooting

### `node` or `npm` is not recognized

Close and reopen PowerShell after installing Node.js. If the error remains,
reinstall Node.js and ensure **Add to PATH** is selected.

### Port 5173 is already in use

```powershell
npm run dev -- --port 5174
```

Then open http://localhost:5174.

### Dependency installation fails

Confirm that your corporate proxy permits `registry.npmjs.org`. If your bank
provides an npm proxy, configure it according to your internal support guidance
and rerun `npm ci`.

### The graph is blank

Use `Ctrl+F5` for a hard refresh. Confirm both graph libraries are installed:

```powershell
npm list cytoscape cytoscape-fcose
```

### Windows firewall prompt

Allow Node.js on **Private networks** only. The recommended development command
binds to `127.0.0.1`, so the app is accessible only from the same laptop.

## Security note

The login is a UI simulation, not production authentication. Do not use
confidential or real client information in this demonstration.

