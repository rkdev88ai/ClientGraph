@echo off
setlocal
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js was not found. Install Node.js 22 LTS from https://nodejs.org/
  pause
  exit /b 1
)

if not exist node_modules (
  echo Installing the locked dependencies...
  call npm ci
  if errorlevel 1 exit /b 1
)

echo Building the optimized application...
call npm run build
if errorlevel 1 (
  echo Build failed. Review the messages above and WINDOWS_SETUP.md.
  pause
  exit /b 1
)

echo.
echo Starting the optimized local server...
echo Press Ctrl+C to stop the server.
echo.
call npm run start

