# Client Knowledge Studio

Windows-ready source package for the corporate client onboarding demonstration.

Start with [WINDOWS_SETUP.md](WINDOWS_SETUP.md), or double-click
`start-local.cmd` after installing Node.js 22 LTS.

The source includes the React UI, Node.js tooling, Cytoscape.js client graph,
fCoSE force-directed layout, exact npm lockfile and local-hosting scripts.

