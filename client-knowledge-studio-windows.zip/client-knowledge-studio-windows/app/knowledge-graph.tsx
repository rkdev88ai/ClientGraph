"use client";

import { useEffect, useRef, useState } from "react";
import type { Core } from "cytoscape";
import { Crosshair, Maximize2, Orbit, RotateCcw, Search, Sparkles } from "lucide-react";
import { graphElements } from "./demo-data";

type SelectedKnowledge = { label: string; detail: string; type: string };

const fcoseLayout = {
  name: "fcose",
  quality: "default",
  randomize: true,
  animate: true,
  animationDuration: 700,
  fit: true,
  padding: 90,
  nodeDimensionsIncludeLabels: true,
  uniformNodeDimensions: false,
  packComponents: true,
  nodeRepulsion: () => 7000,
  idealEdgeLength: () => 135,
  edgeElasticity: () => 0.42,
  nestingFactor: 0.12,
  gravity: 0.3,
  gravityRange: 3.8,
  numIter: 2500,
  tile: true,
  tilingPaddingVertical: 24,
  tilingPaddingHorizontal: 24,
} as never;

export function KnowledgeGraph() {
  const containerRef = useRef<HTMLDivElement>(null);
  const cyRef = useRef<Core | null>(null);
  const [selected, setSelected] = useState<SelectedKnowledge>({ label: "Meridian Components", detail: "Client · Singapore", type: "client" });
  const [filter, setFilter] = useState("all");
  const [query, setQuery] = useState("");
  const [layoutReady, setLayoutReady] = useState(false);

  useEffect(() => {
    let mounted = true;
    Promise.all([import("cytoscape"), import("cytoscape-fcose")]).then(([{ default: cytoscape }, { default: fcose }]) => {
      if (!mounted || !containerRef.current) return;
      cytoscape.use(fcose as never);
      const cy = cytoscape({
        container: containerRef.current,
        elements: graphElements,
        wheelSensitivity: 0.22,
        minZoom: 0.45,
        maxZoom: 2.1,
        layout: { name: "preset" },
        style: [
          { selector: "node", style: { "background-color": "#ffffff", "border-width": 3, "border-color": "#9db8c5", label: "data(label)", color: "#173b4e", "font-size": 11, "font-weight": 600, "text-wrap": "wrap", "text-max-width": 105, "text-valign": "bottom", "text-margin-y": 12, width: 54, height: 54, "overlay-opacity": 0 } },
          { selector: 'node[type = "client"]', style: { "background-color": "#0d5b67", "border-color": "#7ce4cf", color: "#0b3542", width: 76, height: 76, "font-size": 13 } },
          { selector: 'node[type = "person"]', style: { "background-color": "#e8f7f4", "border-color": "#12a88b" } },
          { selector: 'node[type = "entity"]', style: { "background-color": "#eaf1ff", "border-color": "#557dd8" } },
          { selector: 'node[type = "related"]', style: { "background-color": "#f3efff", "border-color": "#8367c7" } },
          { selector: 'node[type = "domain"]', style: { "background-color": "#e8f4ff", "border-color": "#3f8fcb", shape: "round-rectangle" } },
          { selector: 'node[type = "risk"]', style: { "background-color": "#fff3df", "border-color": "#dc8d25", shape: "round-rectangle" } },
          { selector: 'node[type = "evidence"]', style: { "background-color": "#f1f4f5", "border-color": "#718892", shape: "round-rectangle" } },
          { selector: "edge", style: { width: 1.8, "line-color": "#b7c9d0", "target-arrow-color": "#839ba5", "target-arrow-shape": "triangle", "curve-style": "bezier", label: "data(label)", "font-size": 8, color: "#5f7780", "text-background-color": "#f6fafb", "text-background-opacity": 0.95, "text-background-padding": 3, "overlay-opacity": 0 } },
          { selector: "node:selected", style: { "border-width": 5, "border-color": "#f0b74b", "overlay-opacity": 0 } },
          { selector: ".faded", style: { opacity: 0.12 } },
          { selector: ".highlighted", style: { opacity: 1, "line-color": "#13a389", "target-arrow-color": "#13a389", width: 3 } },
          { selector: ".search-dim", style: { opacity: 0.1 } },
          { selector: ".search-match", style: { opacity: 1, "border-width": 6, "border-color": "#f0b74b" } },
        ],
      });
      cyRef.current = cy;
      cy.one("layoutstop", () => setLayoutReady(true));
      cy.layout(fcoseLayout).run();
      cy.on("tap", "node", (event) => {
        const node = event.target;
        setSelected({ label: node.data("label"), detail: node.data("detail"), type: node.data("type") });
        cy.elements().removeClass("highlighted faded");
        cy.elements().addClass("faded");
        node.closedNeighborhood().removeClass("faded").addClass("highlighted");
      });
      cy.on("tap", (event) => {
        if (event.target === cy) cy.elements().removeClass("highlighted faded");
      });
    });
    return () => { mounted = false; cyRef.current?.destroy(); };
  }, []);

  useEffect(() => {
    const cy = cyRef.current;
    if (!cy) return;
    cy.elements().removeClass("faded highlighted");
    if (filter === "ownership") cy.nodes().filter((n) => !["client", "person", "entity", "related"].includes(n.data("type"))).addClass("faded");
    if (filter === "compliance") cy.nodes().filter((n) => ["person", "entity", "related"].includes(n.data("type"))).addClass("faded");
  }, [filter]);

  useEffect(() => {
    const cy = cyRef.current;
    if (!cy) return;
    const term = query.trim().toLowerCase();
    cy.elements().removeClass("search-match search-dim");
    if (!term) return;
    const matches = cy.nodes().filter((node) => `${node.data("label")} ${node.data("detail")}`.toLowerCase().includes(term));
    cy.elements().addClass("search-dim");
    matches.union(matches.connectedEdges()).union(matches.neighborhood("node")).removeClass("search-dim");
    matches.addClass("search-match");
    if (matches.length) cy.animate({ fit: { eles: matches.union(matches.neighborhood()), padding: 100 }, duration: 350 });
  }, [query]);

  const runLayout = () => {
    const cy = cyRef.current;
    if (!cy) return;
    setLayoutReady(false);
    cy.elements().removeClass("faded highlighted search-match search-dim");
    cy.one("layoutstop", () => setLayoutReady(true));
    cy.layout(fcoseLayout).run();
  };

  const reset = () => {
    cyRef.current?.elements().removeClass("faded highlighted search-match search-dim");
    cyRef.current?.fit(undefined, 90);
    setFilter("all");
    setQuery("");
    setSelected({ label: "Meridian Components", detail: "Client · Singapore", type: "client" });
  };

  return (
    <div className="graph-view">
      <div className="graph-toolbar">
        <div>
          <div className="graph-eyebrow"><Sparkles size={14} /> Live client knowledge <span className="layout-chip"><Orbit size={12} /> fCoSE force-directed</span></div>
          <h2>Meridian Components Pte. Ltd.</h2>
          <p>24 accepted facts · 12 relationships · 4 assessments in progress</p>
        </div>
        <div className="graph-controls">
          <div className="graph-search"><Search size={16} /><input aria-label="Search graph" placeholder="Find a person, entity or assessment" value={query} onChange={(event) => setQuery(event.target.value)} /></div>
          <select aria-label="Filter graph" value={filter} onChange={(event) => setFilter(event.target.value)}>
            <option value="all">Complete client view</option>
            <option value="ownership">Ownership network</option>
            <option value="compliance">Compliance context</option>
          </select>
          <button className="layout-button" onClick={runLayout} aria-label="Re-run force-directed layout"><Orbit size={16} /> {layoutReady ? "Re-layout" : "Arranging…"}</button>
          <button className="icon-button light" onClick={() => cyRef.current?.fit(undefined, 70)} aria-label="Fit graph"><Maximize2 size={17} /></button>
          <button className="icon-button light" onClick={reset} aria-label="Reset graph"><RotateCcw size={17} /></button>
        </div>
      </div>
      <div className="graph-stage">
        <div ref={containerRef} className="cytoscape-canvas" />
        <div className="graph-legend" aria-label="Graph legend">
          <span><i className="legend-dot client" /> Client</span>
          <span><i className="legend-dot person" /> Person</span>
          <span><i className="legend-dot entity" /> Entity</span>
          <span><i className="legend-dot domain" /> Assessment</span>
          <span><i className="legend-dot risk" /> Attention</span>
        </div>
        <div className="graph-inspector">
          <div className={`node-symbol ${selected.type}`}><Crosshair size={18} /></div>
          <div>
            <span>Selected knowledge</span>
            <strong>{selected.label}</strong>
            <p>{selected.detail}</p>
          </div>
        </div>
        <div className="graph-note"><span className="live-pulse" /> Select any node to reveal its immediate relationships</div>
      </div>
    </div>
  );
}
