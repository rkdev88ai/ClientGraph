import {
  Building2,
  Network,
  Landmark,
  Scale,
  ShieldCheck,
  WalletCards,
} from "lucide-react";

export type Field = {
  label: string;
  value: string;
  status: "Verified" | "Needs review" | "Missing" | "In progress";
  source: string;
  description?: string;
};

export type Stage = {
  id: string;
  label: string;
  shortLabel: string;
  completion: number;
  status: "Complete" | "In progress" | "Not started";
  description: string;
  icon: typeof Building2;
  fields: Field[];
  nextAction: string;
  owner: string;
};

export const stages: Stage[] = [
  {
    id: "entity",
    label: "Entity profile",
    shortLabel: "Entity",
    completion: 100,
    status: "Complete",
    description: "Core identity, incorporation and business profile",
    icon: Building2,
    owner: "Client Manager",
    nextAction: "No action required",
    fields: [
      { label: "Legal name", value: "Meridian Components Pte. Ltd.", status: "Verified", source: "ACRA business profile" },
      { label: "Registration number", value: "201405812N", status: "Verified", source: "ACRA business profile" },
      { label: "Country of incorporation", value: "Singapore", status: "Verified", source: "Certificate of incorporation" },
      { label: "Incorporation date", value: "12 May 2014", status: "Verified", source: "Certificate of incorporation" },
      { label: "Legal form", value: "Private company limited by shares", status: "Verified", source: "ACRA business profile" },
      { label: "Primary activity", value: "Manufacture of industrial components", status: "Verified", source: "Client declaration" },
      { label: "Registered address", value: "10 Example Industrial Avenue, Singapore 528821", status: "Verified", source: "ACRA business profile" },
      { label: "Client segment", value: "Large Corporate", status: "Verified", source: "CRM classification" },
    ],
  },
  {
    id: "ownership",
    label: "Ownership & control",
    shortLabel: "Ownership",
    completion: 72,
    status: "In progress",
    description: "Legal hierarchy, ownership paths and control assessment",
    icon: Network,
    owner: "KYC Operations",
    nextAction: "Confirm control rights held by Cara Lim",
    fields: [
      { label: "Direct ownership coverage", value: "100%", status: "Verified", source: "Shareholder register" },
      { label: "Meridian Holdings B.V.", value: "60% direct owner", status: "Verified", source: "Shareholder register" },
      { label: "Ana Rao", value: "50% effective ownership", status: "Verified", source: "Calculated from 2 ownership paths" },
      { label: "Ben Tan", value: "30% effective ownership", status: "Verified", source: "Calculated from 1 ownership path" },
      { label: "Cara Lim", value: "20% effective ownership", status: "Needs review", source: "Harbour Ventures ownership evidence", description: "Board appointment rights are awaiting confirmation." },
      { label: "Ownership criterion", value: "25% or more", status: "Verified", source: "SG Corporate KYC Policy v2026.09" },
      { label: "Control assessment", value: "Pending", status: "Missing", source: "Shareholder agreement required" },
      { label: "Provisional UBOs", value: "Ana Rao · Ben Tan", status: "In progress", source: "UBO assessment engine" },
    ],
  },
  {
    id: "tax",
    label: "Tax compliance",
    shortLabel: "Tax",
    completion: 55,
    status: "In progress",
    description: "Tax residence, FATCA, CRS and withholding tax",
    icon: Landmark,
    owner: "Tax Operations",
    nextAction: "Validate entity self-certification",
    fields: [
      { label: "Tax residence", value: "Singapore", status: "Needs review", source: "Entity self-certification" },
      { label: "Tax identification number", value: "T26-0145821-N", status: "Needs review", source: "Entity self-certification" },
      { label: "FATCA classification", value: "Active NFFE", status: "In progress", source: "FATCA decision service" },
      { label: "CRS classification", value: "Active NFE", status: "In progress", source: "CRS decision service" },
      { label: "Controlling persons", value: "Assessment pending", status: "Missing", source: "Ownership assessment" },
      { label: "Self-certification validity", value: "Awaiting validation", status: "Missing", source: "Tax Operations" },
    ],
  },
  {
    id: "regulatory",
    label: "Regulatory classification",
    shortLabel: "Regulatory",
    completion: 40,
    status: "In progress",
    description: "Product and jurisdiction-specific client classifications",
    icon: Scale,
    owner: "Regulatory Operations",
    nextAction: "Obtain accredited investor election",
    fields: [
      { label: "Requested product", value: "FX forwards", status: "Verified", source: "Client service request" },
      { label: "Booking location", value: "Singapore", status: "Verified", source: "Client service request" },
      { label: "MAS investor eligibility", value: "Eligible", status: "Verified", source: "Eligibility rule assessment" },
      { label: "Accredited investor status", value: "Pending opt-in", status: "Missing", source: "Client election required" },
      { label: "EMIR applicability", value: "Not applicable for current scope", status: "Verified", source: "Regulatory applicability rules" },
      { label: "MiFID classification", value: "Not applicable for current scope", status: "Verified", source: "Regulatory applicability rules" },
    ],
  },
  {
    id: "kyc",
    label: "KYC & due diligence",
    shortLabel: "KYC",
    completion: 30,
    status: "In progress",
    description: "Screening, risk assessment and enhanced due diligence",
    icon: ShieldCheck,
    owner: "Financial Crime Compliance",
    nextAction: "Review potential PEP match for Ana Rao",
    fields: [
      { label: "Entity sanctions screening", value: "No match", status: "Verified", source: "Screening run · 06 Sep 2026" },
      { label: "Related-party coverage", value: "4 of 6 parties", status: "In progress", source: "Party screening register" },
      { label: "Ana Rao PEP screening", value: "Potential match", status: "Needs review", source: "Screening provider result" },
      { label: "Adverse media", value: "No material result", status: "Verified", source: "2-year media search" },
      { label: "Client risk rating", value: "Not yet determined", status: "Missing", source: "Awaiting ownership and screening" },
      { label: "Enhanced due diligence", value: "Conditional", status: "In progress", source: "KYC policy rules" },
    ],
  },
  {
    id: "accounts",
    label: "Account provisioning",
    shortLabel: "Accounts",
    completion: 0,
    status: "Not started",
    description: "Product activation, controls and downstream provisioning",
    icon: WalletCards,
    owner: "Product Operations",
    nextAction: "Complete all blocking onboarding requirements",
    fields: [
      { label: "Cash management account", value: "Awaiting onboarding approval", status: "Missing", source: "Product request" },
      { label: "FX trading account", value: "Awaiting regulatory classification", status: "Missing", source: "Product request" },
      { label: "Activation decision", value: "Blocked", status: "Missing", source: "Readiness gate" },
      { label: "Downstream provisioning", value: "Not initiated", status: "Missing", source: "Account provisioning" },
    ],
  },
];

export const cases = [
  { id: "CB-2026-1048", name: "Meridian Components Pte. Ltd.", country: "Singapore", product: "Cash · FX", completion: 49, priority: "Action required", due: "12 Sep", active: true, initials: "MC" },
  { id: "CB-2026-1031", name: "Northstar Renewables GmbH", country: "Germany", product: "Lending", completion: 81, priority: "On track", due: "16 Sep", initials: "NR" },
  { id: "CB-2026-1026", name: "Amara Foods Group Ltd.", country: "United Kingdom", product: "Trade · Cash", completion: 68, priority: "Client response", due: "14 Sep", initials: "AF" },
  { id: "CB-2026-0994", name: "Keystone Maritime S.A.", country: "Greece", product: "Trade Finance", completion: 92, priority: "Approval", due: "09 Sep", initials: "KM" },
  { id: "CB-2026-0972", name: "Juniper Health Holdings", country: "Australia", product: "Cash", completion: 34, priority: "In progress", due: "22 Sep", initials: "JH" },
];

export const activities = [
  { time: "09:42", title: "Ownership evidence verified", detail: "Shareholder register accepted by KYC Operations", kind: "success" },
  { time: "09:18", title: "Potential PEP match identified", detail: "Ana Rao requires identity adjudication", kind: "attention" },
  { time: "Yesterday", title: "Tax self-certification received", detail: "Validation task assigned to Tax Operations", kind: "info" },
  { time: "04 Sep", title: "Client service scope confirmed", detail: "Cash management and FX forwards · Singapore", kind: "info" },
];

export const graphElements = {
  nodes: [
    { data: { id: "client", label: "Meridian Components", type: "client", detail: "Client · Singapore" } },
    { data: { id: "holdings", label: "Meridian Holdings B.V.", type: "entity", detail: "Legal entity · Netherlands" } },
    { data: { id: "harbour", label: "Harbour Ventures Ltd.", type: "entity", detail: "Legal entity · United Kingdom" } },
    { data: { id: "ana", label: "Ana Rao", type: "person", detail: "Person · 50% effective ownership" } },
    { data: { id: "ben", label: "Ben Tan", type: "person", detail: "Person · 30% effective ownership" } },
    { data: { id: "cara", label: "Cara Lim", type: "person", detail: "Person · 20% effective ownership" } },
    { data: { id: "horizon", label: "Horizon Logistics", type: "related", detail: "Separate bank client" } },
    { data: { id: "tax", label: "Tax profile", type: "domain", detail: "55% complete" } },
    { data: { id: "reg", label: "Regulatory", type: "domain", detail: "40% complete" } },
    { data: { id: "screen", label: "Screening", type: "risk", detail: "Potential PEP match" } },
    { data: { id: "risk", label: "Client risk", type: "risk", detail: "Incomplete" } },
    { data: { id: "evidence", label: "Evidence set", type: "evidence", detail: "12 documents · 9 verified" } },
  ],
  edges: [
    { data: { id: "e1", source: "holdings", target: "client", label: "OWNS 60%" } },
    { data: { id: "e2", source: "ana", target: "client", label: "OWNS 20%" } },
    { data: { id: "e3", source: "harbour", target: "client", label: "OWNS 20%" } },
    { data: { id: "e4", source: "ana", target: "holdings", label: "OWNS 50%" } },
    { data: { id: "e5", source: "ben", target: "holdings", label: "OWNS 50%" } },
    { data: { id: "e6", source: "cara", target: "harbour", label: "OWNS 100%" } },
    { data: { id: "e7", source: "ana", target: "horizon", label: "OWNS 35%" } },
    { data: { id: "e8", source: "client", target: "tax", label: "HAS PROFILE" } },
    { data: { id: "e9", source: "client", target: "reg", label: "ASSESSED FOR" } },
    { data: { id: "e10", source: "ana", target: "screen", label: "SCREENED BY" } },
    { data: { id: "e11", source: "client", target: "risk", label: "HAS RISK" } },
    { data: { id: "e12", source: "evidence", target: "client", label: "SUPPORTS" } },
  ],
};
