"use client";

import { FormEvent, useMemo, useState } from "react";
import {
  Activity,
  ArrowLeft,
  ArrowRight,
  Bell,
  BookOpenText,
  BriefcaseBusiness,
  Building2,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  CircleAlert,
  Clock3,
  FileCheck2,
  Filter,
  HelpCircle,
  Inbox,
  LayoutDashboard,
  LockKeyhole,
  LogOut,
  Menu,
  Network,
  Plus,
  Search,
  ShieldCheck,
  Sparkles,
  Users,
  X,
} from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { activities, cases, stages, type Field } from "./demo-data";
import { KnowledgeGraph } from "./knowledge-graph";

function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="brand-lockup">
      <div className="brand-mark"><span /><span /><span /></div>
      {!compact && <div><strong>Clarity</strong><small>CLIENT KNOWLEDGE</small></div>}
    </div>
  );
}

function Login({ onLogin }: { onLogin: () => void }) {
  const [busy, setBusy] = useState(false);
  const submit = (event: FormEvent) => {
    event.preventDefault();
    setBusy(true);
    window.setTimeout(onLogin, 650);
  };
  return (
    <main className="login-shell">
      <section className="login-story">
        <Logo />
        <div className="story-content">
          <span className="story-kicker"><Sparkles size={15} /> A connected view of every client</span>
          <h1>Turn onboarding<br />into knowledge.</h1>
          <p>Understand the client, their ownership, obligations and risk through one clear, evidence-backed view.</p>
          <div className="story-proof">
            <div><Network size={21} /><span><strong>Every relationship connected</strong><small>See how client knowledge grows as work progresses</small></span></div>
            <div><ShieldCheck size={21} /><span><strong>Every decision explainable</strong><small>Trace each fact to its policy, source and reviewer</small></span></div>
          </div>
        </div>
        <p className="story-foot">Corporate & Institutional Banking · Client Lifecycle Management</p>
      </section>
      <section className="login-panel">
        <div className="login-card">
          <span className="secure"><LockKeyhole size={14} /> Secure workspace</span>
          <h2>Welcome back</h2>
          <p>Sign in to continue to your client onboarding workspace.</p>
          <form onSubmit={submit}>
            <label>Work email<input type="email" defaultValue="alex.morgan@bank.example" required /></label>
            <label>Password<div className="password-wrap"><input type="password" defaultValue="demo-password" required /><button type="button">Show</button></div></label>
            <div className="login-options"><label><input type="checkbox" defaultChecked /> Keep me signed in</label><button type="button">Need help?</button></div>
            <button className="primary-action" type="submit" disabled={busy}>{busy ? <><span className="spinner" /> Signing in…</> : <>Sign in securely <ArrowRight size={18} /></>}</button>
          </form>
          <div className="sso-divider"><span>or continue with</span></div>
          <button className="sso-button"><span className="sso-glyph">S</span> Enterprise single sign-on</button>
          <p className="demo-hint">Demo credentials are already filled in.</p>
        </div>
        <p className="legal">Authorised bank users only · Activity is monitored and recorded</p>
      </section>
    </main>
  );
}

function StatusPill({ status }: { status: Field["status"] }) {
  return <span className={`status-pill ${status.toLowerCase().replaceAll(" ", "-")}`}>{status === "Verified" && <Check size={12} />}{status}</span>;
}

function OverallRing({ value }: { value: number }) {
  return <div className="overall-ring" style={{ "--progress": `${value * 3.6}deg` } as React.CSSProperties}><div><strong>{value}%</strong><span>overall</span></div></div>;
}

function CaseInbox({ onOpen }: { onOpen: () => void }) {
  const [query, setQuery] = useState("");
  const filtered = useMemo(() => cases.filter((item) => item.name.toLowerCase().includes(query.toLowerCase()) || item.id.toLowerCase().includes(query.toLowerCase())), [query]);
  return (
    <main className="inbox-page">
      <header className="page-heading">
        <div><span className="section-kicker">CLIENT ONBOARDING</span><h1>Good morning, Alex</h1><p>Here is what needs your attention across your portfolio.</p></div>
        <button className="new-case"><Plus size={17} /> Start onboarding</button>
      </header>
      <section className="metric-grid">
        <article><div className="metric-icon teal"><Inbox size={20} /></div><span>My active cases</span><strong>12</strong><small><b>3</b> require action</small></article>
        <article><div className="metric-icon blue"><Clock3 size={20} /></div><span>Approaching due date</span><strong>4</strong><small>Within the next 7 days</small></article>
        <article><div className="metric-icon amber"><CircleAlert size={20} /></div><span>Client responses</span><strong>3</strong><small>Awaiting your review</small></article>
        <article><div className="metric-icon violet"><Activity size={20} /></div><span>Completed this month</span><strong>8</strong><small><b>+14%</b> from last month</small></article>
      </section>
      <section className="inbox-card">
        <div className="inbox-head"><div><h2>My inbox</h2><p>Client onboarding cases assigned to you</p></div><div className="inbox-actions"><div className="case-search"><Search size={16} /><input aria-label="Search cases" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search clients or cases" /></div><button className="secondary-button"><Filter size={16} /> Filter</button></div></div>
        <div className="case-table-head"><span>Client</span><span>Products</span><span>Progress</span><span>Next due</span><span>Status</span><span /></div>
        <div className="case-list">
          {filtered.map((item, index) => <button key={item.id} className="case-row" onClick={index === 0 ? onOpen : undefined}>
            <span className={`client-avatar tone-${index % 5}`}>{item.initials}</span>
            <span className="case-client"><strong>{item.name}</strong><small>{item.id} · {item.country}</small></span>
            <span className="case-product">{item.product}</span>
            <span className="case-progress"><span><b>{item.completion}%</b></span><Progress value={item.completion} /></span>
            <span className="case-due"><CalendarDays size={15} /> {item.due}</span>
            <span className={`priority ${item.priority.toLowerCase().replaceAll(" ", "-")}`}>{item.priority}</span>
            <ChevronRight size={18} className="row-chevron" />
          </button>)}
        </div>
      </section>
      <p className="inbox-footnote"><CheckCircle2 size={14} /> Portfolio refreshed moments ago</p>
    </main>
  );
}

function Journey({ activeId, onSelect }: { activeId: string; onSelect: (id: string) => void }) {
  return <section className="journey-card">
    <div className="journey-title"><div><span className="section-kicker">ONBOARDING JOURNEY</span><h2>Progress towards activation</h2></div><div className="overall-summary"><span>Overall completion</span><strong>49%</strong><Progress value={49} /></div></div>
    <div className="journey-track">
      {stages.map((stage, index) => { const Icon = stage.icon; return <button key={stage.id} className={`journey-step ${stage.id === activeId ? "active" : ""} ${stage.status === "Complete" ? "complete" : ""}`} onClick={() => onSelect(stage.id)}>
        {index < stages.length - 1 && <span className="journey-line"><i style={{ width: `${Math.min(stage.completion, 100)}%` }} /></span>}
        <span className="step-orbit"><Icon size={18} /></span>
        <span className="step-copy"><strong>{stage.shortLabel}</strong><small>{stage.completion}% complete</small></span>
      </button>; })}
    </div>
  </section>;
}

function CaseWorkspace({ onBack, onOpenGraph }: { onBack: () => void; onOpenGraph: () => void }) {
  const [activeId, setActiveId] = useState("ownership");
  const stage = stages.find((item) => item.id === activeId)!;
  return (
    <main className="case-page">
      <header className="case-heading">
        <div className="case-title-wrap"><button className="back-button" onClick={onBack}><ArrowLeft size={18} /></button><div><div className="breadcrumb">My inbox <ChevronRight size={13} /> {cases[0].id}</div><h1>{cases[0].name}</h1><p><span className="case-badge">Large Corporate</span> Singapore · Cash Management & FX Forwards</p></div></div>
        <div className="case-header-actions">
          <button className="case-graph-button" onClick={onOpenGraph} aria-label="Open client knowledge graph"><Network size={18} /><span>Client graph</span><b>24 facts</b></button>
          <TooltipProvider>
            <Tooltip><TooltipTrigger render={<SheetTrigger className="icon-button header-icon" aria-label="Open client information"><BookOpenText size={19} /></SheetTrigger>}><span /></TooltipTrigger><TooltipContent>Client information</TooltipContent></Tooltip>
          </TooltipProvider>
        </div>
      </header>
      <Journey activeId={activeId} onSelect={setActiveId} />
      <div className="workspace-grid">
        <section className="stage-panel">
          <div className="stage-head"><div className="stage-icon"><stage.icon size={21} /></div><div><span>{stage.status}</span><h2>{stage.label}</h2><p>{stage.description}</p></div><div className="stage-score"><strong>{stage.completion}%</strong><span>complete</span></div></div>
          <div className="context-strip"><span><Users size={15} /> Owner <b>{stage.owner}</b></span><span><CircleAlert size={15} /> Next action <b>{stage.nextAction}</b></span></div>
          <div className="field-grid">
            {stage.fields.map((field) => <article key={field.label} className={`field-card ${field.status.toLowerCase().replaceAll(" ", "-")}`}>
              <div className="field-label"><span>{field.label}</span><StatusPill status={field.status} /></div>
              <strong>{field.value}</strong>
              {field.description && <p>{field.description}</p>}
              <small><FileCheck2 size={13} /> {field.source}</small>
            </article>)}
          </div>
        </section>
        <aside className="work-aside">
          <article className="attention-card"><span className="aside-kicker"><CircleAlert size={15} /> YOUR NEXT ACTION</span><h3>{stage.nextAction}</h3><p>Complete this item to move the {stage.shortLabel.toLowerCase()} stage forward.</p><button>Open task <ArrowRight size={15} /></button></article>
          <article className="activity-card"><div className="aside-title"><h3>Recent activity</h3><button>View all</button></div><div className="activity-list">{activities.map((item) => <div key={item.title} className="activity-item"><i className={item.kind} /><div><span>{item.time}</span><strong>{item.title}</strong><p>{item.detail}</p></div></div>)}</div></article>
        </aside>
      </div>
    </main>
  );
}

function InfoDrawer() {
  return (
    <SheetContent className="info-sheet" side="right">
      <SheetHeader className="drawer-header"><div className="drawer-client"><span className="client-avatar tone-0">MC</span><div><span>CLIENT INFORMATION</span><SheetTitle>Meridian Components</SheetTitle><SheetDescription>CB-2026-1048 · Singapore</SheetDescription></div></div></SheetHeader>
      <div className="drawer-scroll">
        <section className="readiness-card"><OverallRing value={49} /><div><span>Onboarding readiness</span><strong>4 blocking items remain</strong><p>Target completion · 18 September 2026</p></div></section>
        <section className="drawer-section"><h3>Relationship</h3><div className="summary-list"><div><span>Client manager</span><strong>Alex Morgan</strong></div><div><span>Bank entity</span><strong>Example Bank Singapore Ltd.</strong></div><div><span>Segment</span><strong>Large Corporate</strong></div><div><span>Relationship type</span><strong>New to bank</strong></div></div></section>
        <section className="drawer-section"><h3>Requested services</h3><div className="service-list"><span><BriefcaseBusiness size={16} /> Cash Management <b>Singapore</b></span><span><Activity size={16} /> FX Forwards <b>Singapore</b></span></div></section>
        <section className="drawer-section"><div className="section-row"><h3>Journey status</h3><span>49% overall</span></div><div className="mini-stages">{stages.map((stage) => <div key={stage.id}><span>{stage.shortLabel}</span><Progress value={stage.completion} /><strong>{stage.completion}%</strong></div>)}</div></section>
        <section className="drawer-section"><h3>Knowledge created</h3><div className="knowledge-metrics"><div><strong>24</strong><span>Accepted facts</span></div><div><strong>12</strong><span>Relationships</span></div><div><strong>9</strong><span>Verified sources</span></div></div></section>
        <section className="drawer-section"><h3>Important dates</h3><div className="timeline-list"><div><i /><span><small>Started</small><strong>02 Sep 2026</strong></span></div><div><i /><span><small>Client response due</small><strong>12 Sep 2026</strong></span></div><div><i /><span><small>Target completion</small><strong>18 Sep 2026</strong></span></div></div></section>
      </div>
    </SheetContent>
  );
}

function AppShell({ onLogout }: { onLogout: () => void }) {
  const [view, setView] = useState<"inbox" | "case">("inbox");
  const [graphOpen, setGraphOpen] = useState(false);
  return (
    <>
      <Sheet>
        <div className="app-shell">
        <aside className="app-nav">
          <Logo />
          <nav>
            <button className="nav-item"><LayoutDashboard size={18} /><span>Overview</span></button>
            <button className="nav-item active"><Inbox size={18} /><span>My inbox</span><b>12</b></button>
            <button className="nav-item"><Users size={18} /><span>Clients</span></button>
            <button className="nav-item"><Activity size={18} /><span>Activity</span></button>
          </nav>
          <div className="nav-lower"><button><HelpCircle size={18} /><span>Help centre</span></button><div className="profile"><span>AM</span><div><strong>Alex Morgan</strong><small>Client Manager</small></div><ChevronDown size={15} /></div><button className="logout" onClick={onLogout}><LogOut size={16} /><span>Sign out</span></button></div>
        </aside>
        <section className="app-main">
          <div className="utility-bar"><button className="mobile-menu"><Menu size={18} /></button><div className="global-search"><Search size={16} /><input aria-label="Search the workspace" placeholder="Search clients, cases or tasks" /></div><div className="utility-actions"><button className="icon-button"><Bell size={18} /><i /></button>{view === "case" && <><SheetTrigger className="icon-button special" aria-label="Open client information"><BookOpenText size={18} /></SheetTrigger><button className="graph-launch" onClick={() => setGraphOpen(true)} aria-label="Open client knowledge graph"><Network size={18} /><span>Client graph</span><b>24</b></button></>}<span className="utility-avatar">AM</span></div></div>
          {view === "inbox" ? <CaseInbox onOpen={() => setView("case")} /> : <CaseWorkspace onBack={() => setView("inbox")} onOpenGraph={() => setGraphOpen(true)} />}
        </section>
        </div>
        <InfoDrawer />
      </Sheet>
      <GraphSheet open={graphOpen} onOpenChange={setGraphOpen} />
    </>
  );
}

function GraphSheet({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  return <Sheet open={open} onOpenChange={onOpenChange}><SheetContent className="graph-sheet" side="right" showCloseButton={false}><div className="graph-sheet-top"><div className="graph-brand"><Logo /><span>Knowledge graph</span></div><button className="graph-close" onClick={() => onOpenChange(false)}><X size={19} /> Close graph</button></div>{open && <KnowledgeGraph />}</SheetContent></Sheet>;
}

export default function Home() {
  const [loggedIn, setLoggedIn] = useState(false);
  return loggedIn ? <AppShell onLogout={() => setLoggedIn(false)} /> : <Login onLogin={() => setLoggedIn(true)} />;
}
