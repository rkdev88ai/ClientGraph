#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
case "$project_dir" in
  *" "*) echo "Move the project to a path without spaces before installing the service." >&2; exit 1 ;;
esac

config_base="${XDG_CONFIG_HOME:-${HOME}/.config}"
unit_dir="$config_base/systemd/user"
unit_path="$unit_dir/client-graph-poc.service"
if [[ -z "${XDG_RUNTIME_DIR:-}" ]]; then
  export XDG_RUNTIME_DIR="/run/user/$(id -u)"
fi
mkdir -p "$unit_dir"
sed "s|__PROJECT_DIR__|$project_dir|g" "$project_dir/deploy/systemd/client-graph-poc.service.template" > "$unit_path"
systemctl --user daemon-reload
systemctl --user enable --now client-graph-poc.service

echo "Installed and started client-graph-poc.service for user ${USER}."
echo "For startup without an interactive login, an administrator should run:"
echo "  sudo loginctl enable-linger ${USER}"
echo "Check status with: systemctl --user status client-graph-poc.service"
