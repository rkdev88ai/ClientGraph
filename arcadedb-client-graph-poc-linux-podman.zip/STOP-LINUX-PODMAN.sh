#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$project_dir"

if podman compose version >/dev/null 2>&1; then
  compose_command=(podman compose)
elif command -v podman-compose >/dev/null 2>&1; then
  compose_command=(podman-compose)
else
  echo "No Podman Compose provider was found." >&2
  exit 1
fi

"${compose_command[@]}" -f compose.linux.yaml down
echo "Containers stopped. Persistent volumes were retained."
