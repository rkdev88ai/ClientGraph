#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$project_dir"

if ! command -v podman >/dev/null 2>&1; then
  echo "Podman is required. Install Podman and a Compose provider first." >&2
  exit 1
fi

if podman compose version >/dev/null 2>&1; then
  compose_command=(podman compose)
elif command -v podman-compose >/dev/null 2>&1; then
  compose_command=(podman-compose)
else
  echo "No Podman Compose provider was found. Install podman-compose or Docker Compose v2." >&2
  exit 1
fi

if [[ ! -f .env ]]; then
  cp .env.example .env
  echo "Created .env. Change ARCADEDB_PASSWORD before production use."
fi

"${compose_command[@]}" -f compose.linux.yaml up -d --build

echo "Waiting for the application and ArcadeDB schema bootstrap..."
for attempt in $(seq 1 45); do
  if curl --fail --silent http://127.0.0.1:${APP_PORT:-3000}/api/health >/dev/null 2>&1; then
    echo "Client Graph POC is ready at http://127.0.0.1:${APP_PORT:-3000}"
    exit 0
  fi
  sleep 2
done

echo "The containers started, but the health check did not pass within 90 seconds." >&2
echo "Inspect logs with: ${compose_command[*]} -f compose.linux.yaml logs --tail=200" >&2
exit 1
