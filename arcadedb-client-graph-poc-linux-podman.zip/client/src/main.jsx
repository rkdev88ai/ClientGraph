import React, { useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import cytoscape from 'cytoscape';
import fcose from 'cytoscape-fcose';
import './styles.css';

cytoscape.use(fcose);

const emptyForm = {
  legalName: '', countryOfIncorporation: '', incorporationNumber: '', legalForm: '',
  addressLine1: '', addressLine2: '', city: '', region: '', postalCode: '', addressCountry: '',
  industryCodes: [{ system: 'ISIC', code: '', description: '' }]
};

function KnowledgeGraph({ clientId, refreshKey }) {
  const container = useRef(null);
  const instance = useRef(null);
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    if (!clientId) return;
    let cancelled = false;
    fetch(`/api/clients/${clientId}/graph`)
      .then(r => r.ok ? r.json() : Promise.reject(new Error('Graph could not be loaded')))
      .then(graph => {
        if (cancelled) return;
        instance.current?.destroy();
        instance.current = cytoscape({
          container: container.current,
          elements: [...graph.nodes, ...graph.edges],
          style: [
            { selector: 'node', style: { 'label': 'data(label)', 'text-wrap': 'wrap', 'text-max-width': 120, 'font-size': 11, 'background-color': '#3772ff', color: '#172033', 'text-valign': 'bottom', 'text-margin-y': 8, width: 42, height: 42 } },
            { selector: 'node[type = "ClientIdentity"]', style: { 'background-color': '#0a7d63', width: 58, height: 58, 'font-weight': 700 } },
            { selector: 'edge', style: { 'label': 'data(label)', 'font-size': 9, 'curve-style': 'bezier', 'target-arrow-shape': 'triangle', 'line-color': '#aeb8c9', 'target-arrow-color': '#aeb8c9', width: 2 } },
            { selector: ':selected', style: { 'border-width': 4, 'border-color': '#ffb000', 'line-color': '#ffb000', 'target-arrow-color': '#ffb000' } }
          ],
          layout: { name: 'fcose', animate: true, randomize: true, quality: 'default', nodeRepulsion: 7000, idealEdgeLength: 130 },
          minZoom: 0.35, maxZoom: 2.5
        });
        instance.current.on('tap', 'node', e => setSelected(e.target.data()));
      })
      .catch(error => setSelected({ label: error.message }));
    return () => { cancelled = true; instance.current?.destroy(); };
  }, [clientId, refreshKey]);

  return <section className="graph-panel">
    <div className="section-title"><div><span className="eyebrow">ARCADEDB PROJECTION</span><h2>Knowledge graph</h2></div><span className="layout-chip">FCoSE layout</span></div>
    <div className="graph-wrap"><div ref={container} className="graph-canvas" />
      {selected && <aside className="node-inspector"><button onClick={() => setSelected(null)}>×</button><strong>{selected.label}</strong><small>{selected.type}</small><dl><dt>Object version</dt><dd>{selected.objectVersion ?? '—'}</dd><dt>Content hash</dt><dd className="mono">{selected.contentHash?.slice(0, 18) ?? '—'}…</dd><dt>JSON file</dt><dd className="mono">{selected.domainObjectPath ?? '—'}</dd><dt>Bound payload</dt><dd><pre>{JSON.stringify(selected.payload, null, 2)}</pre></dd></dl></aside>}
    </div>
  </section>;
}

function App() {
  const [form, setForm] = useState(emptyForm);
  const [active, setActive] = useState(null);
  const [message, setMessage] = useState('Enter a legal name to search existing JSON records.');
  const [suggestions, setSuggestions] = useState([]);
  const [busy, setBusy] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  const change = e => setForm(v => ({ ...v, [e.target.name]: e.target.value }));
  const industryChange = (index, field, value) => setForm(v => ({ ...v, industryCodes: v.industryCodes.map((x, i) => i === index ? { ...x, [field]: value } : x) }));

  useEffect(() => {
    const name = form.legalName.trim();
    if (name.length < 2) { setSuggestions([]); return; }
    const timer = setTimeout(async () => {
      try {
        const result = await fetch(`/api/clients/search?legalName=${encodeURIComponent(name)}`).then(r => r.json());
        setSuggestions(result.suggestions || []);
        if (result.exact) loadClient(result.exact.clientId, false);
      } catch { setMessage('API is unavailable. Check that the Node server and ArcadeDB are running.'); }
    }, 350);
    return () => clearTimeout(timer);
  }, [form.legalName]);

  async function loadClient(clientId, announce = true) {
    const r = await fetch(`/api/clients/${clientId}`);
    if (!r.ok) return;
    const record = await r.json();
    setForm(record.form);
    setActive(record);
    setSuggestions([]);
    if (announce) setMessage(`Loaded ${record.form.legalName} from versioned JSON.`);
  }

  async function submit(e) {
    e.preventDefault(); setBusy(true); setMessage('Writing versioned JSON and updating ArcadeDB…');
    try {
      const r = await fetch('/api/clients', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
      const result = await r.json();
      if (!r.ok) throw new Error(result.error || 'Save failed');
      setActive(result); setRefreshKey(k => k + 1);
      setMessage(`Saved ${result.form.legalName}. Graph and JSON binding: ${result.binding.status}.`);
    } catch (error) { setMessage(error.message); }
    finally { setBusy(false); }
  }

  const addIndustry = () => setForm(v => ({ ...v, industryCodes: [...v.industryCodes, { system: 'NAICS', code: '', description: '' }] }));

  return <main>
    <header><div className="brand"><span>KG</span><div><strong>Client Graph POC</strong><small>Versioned JSON + ArcadeDB</small></div></div><div className={`health ${active?.binding?.status === 'BOUND' ? 'ok' : ''}`}><i />{active ? active.binding.status : 'Not loaded'}</div></header>
    <div className="hero"><span className="eyebrow">ARCHITECTURE PROOF</span><h1>Capture once. Bind every fact.</h1><p>Client data is saved as immutable domain-object JSON and projected into a traceable knowledge graph.</p></div>
    <div className="workspace">
      <form onSubmit={submit} className="form-panel">
        <div className="section-title"><div><span className="eyebrow">CANONICAL INPUT</span><h2>Client details</h2></div>{active && <span className="version-chip">Latest v{String(active.latestVersion).padStart(4, '0')}</span>}</div>
        <div className="field full search-field"><label>Legal name *</label><input name="legalName" value={form.legalName} onChange={change} placeholder="Start typing, e.g. Northstar Components Ltd" required />
          {suggestions.length > 0 && <div className="suggestions">{suggestions.map(s => <button type="button" key={s.clientId} onClick={() => loadClient(s.clientId)}>{s.legalName}<small>{s.clientId}</small></button>)}</div>}
        </div>
        <div className="field"><label>Country of incorporation *</label><input name="countryOfIncorporation" value={form.countryOfIncorporation} onChange={change} placeholder="United Kingdom" required /></div>
        <div className="field"><label>Incorporation number *</label><input name="incorporationNumber" value={form.incorporationNumber} onChange={change} placeholder="12345678" required /></div>
        <div className="field"><label>Legal form</label><input name="legalForm" value={form.legalForm} onChange={change} placeholder="Private limited company" /></div>
        <div className="divider full">Registered address</div>
        <div className="field full"><label>Address line 1 *</label><input name="addressLine1" value={form.addressLine1} onChange={change} placeholder="10 Market Street" required /></div>
        <div className="field full"><label>Address line 2</label><input name="addressLine2" value={form.addressLine2} onChange={change} /></div>
        <div className="field"><label>City *</label><input name="city" value={form.city} onChange={change} required /></div>
        <div className="field"><label>State / region</label><input name="region" value={form.region} onChange={change} /></div>
        <div className="field"><label>Postal code *</label><input name="postalCode" value={form.postalCode} onChange={change} required /></div>
        <div className="field"><label>Address country *</label><input name="addressCountry" value={form.addressCountry} onChange={change} required /></div>
        <div className="divider full">Industry classification <button type="button" onClick={addIndustry}>+ Add code</button></div>
        {form.industryCodes.map((item, index) => <div className="industry full" key={index}>
          <select value={item.system} onChange={e => industryChange(index, 'system', e.target.value)}><option>ISIC</option><option>NAICS</option><option>SIC</option><option>NACE</option></select>
          <input value={item.code} onChange={e => industryChange(index, 'code', e.target.value)} placeholder="Code" required />
          <input value={item.description} onChange={e => industryChange(index, 'description', e.target.value)} placeholder="Description" required />
          {form.industryCodes.length > 1 && <button type="button" aria-label="Remove" onClick={() => setForm(v => ({ ...v, industryCodes: v.industryCodes.filter((_, i) => i !== index) }))}>×</button>}
        </div>)}
        <div className="actions full"><button className="primary" disabled={busy}>{busy ? 'Saving…' : 'Save new version'}</button><span>{message}</span></div>
      </form>
      <KnowledgeGraph clientId={active?.clientId} refreshKey={refreshKey} />
    </div>
    {active?.binding && <section className="lineage"><div><span className="eyebrow">STRICT LINEAGE</span><h2>Binding verification</h2><p>Each ArcadeDB node was read back and compared with the canonical file hash and JSON payload.</p></div><div className="binding-grid">{active.binding.objects.map(x => <article key={x.domainObjectType}><strong>{x.domainObjectType}</strong><span className={x.status === 'BOUND' ? 'bound' : 'drift'}>{x.status}</span><small className="mono">{x.fileName}</small></article>)}</div></section>}
  </main>;
}

createRoot(document.getElementById('root')).render(<App />);
