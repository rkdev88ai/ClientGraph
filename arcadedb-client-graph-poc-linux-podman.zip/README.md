# Client Knowledge Graph POC

A local proof of concept showing strict lineage from versioned, schema-less JSON domain objects to an ArcadeDB graph, exposed only through Node.js APIs and visualized in React with Cytoscape.js using the FCoSE force-directed layout.

For a fully containerized Linux deployment using rootless Podman, see [`LINUX-PODMAN.md`](LINUX-PODMAN.md). The Linux profile runs both this application and ArcadeDB in containers, so Node.js is not required on the host.

## What the POC proves

- A web form captures identity, incorporation, address and industry data.
- Each save creates four immutable JSON domain objects: `ClientIdentity`, `EntityProfile`, `RegisteredAddress`, and `IndustryClassification`.
- Files use the convention `<client-name>__<domain-model>__v0001.json` and are stored in `data/domain-objects`.
- ArcadeDB contains one vertex per domain object and graph edges from the client identity.
- The only declared business-graph property is the indexed `graphKey` technical identifier. All client payload attributes remain schema-less.
- Every vertex stores `domainObjectId`, `objectVersion`, `domainObjectPath`, `contentHash`, canonical `dataJson`, JSON-pointer `bindingsJson`, and a separately verified `bound_<field>` property for each mapped form field.
- The API reads graph records back after every write and reports `BOUND` only when version, hash, payload and bindings exactly match the JSON file.
- Typing an existing legal name searches `data/index.json` and loads the latest JSON versions.

## Windows prerequisites

1. Install **Docker Desktop** and make sure it is running.
2. Install **Node.js 20.19+ or 22.12+** (Node 22 LTS is recommended).
3. Extract this ZIP to a normal local folder such as `C:\Projects\client-graph-poc`. Avoid a OneDrive-controlled folder for the first run.

## One-click Windows start

Double-click `START-WINDOWS.cmd`. The script will:

1. Start ArcadeDB in Docker and create the `clientkg` database.
2. Install Node/React dependencies.
3. Build the UI.
4. Start the API and UI at <http://localhost:3000>.

ArcadeDB Studio and the Node API use `root` with password `playwithdata` for this local POC.

Stop the Node server with **Ctrl+C**. Double-click `STOP-WINDOWS.cmd` to stop ArcadeDB. The named Docker volume keeps the database between runs.

## Fixing `User 'root/admin' is not allowed to update schema`

An earlier POC package used a colon between the database username and password. ArcadeDB `26.5.1`, which this project pins, requires a pipe in the declarative database definition: `clientkg[root|playwithdata]`. The incorrect separator created the database without the expected root schema permissions.

If you started the earlier package and have no data to preserve, stop the Node process and double-click `RESET-ARCADEDB-WINDOWS.cmd`. Confirm the warning, wait for ArcadeDB to restart, and then run `START-WINDOWS.cmd`.

To update an existing extracted folder manually:

1. Change `.env` to `ARCADEDB_USER=root`.
2. In `docker-compose.yml`, change the default database setting to `clientkg[root|playwithdata]`.
3. Run `docker compose down -v` and then `docker compose up -d` from PowerShell. The `-v` operation permanently deletes the old local POC database volume, so do not use it if it contains data you need.

## Fixing `Cannot create the index ... because the property does not exist`

ArcadeDB permits schema-less record attributes, but requires an indexed attribute to be declared. The corrected initializer creates `graphKey` as a `STRING` property on each vertex type before creating its unique index. No database reset is required for this correction: replace the source files, stop the Node process, and run `START-WINDOWS.cmd` again.

## Manual start (PowerShell)

```powershell
Copy-Item .env.example .env
docker compose up -d
npm install
npm run build
npm start
```

Then open <http://localhost:3000>.

For UI/API development with hot reload, run `npm run dev` and open <http://localhost:5173>. The included Vite configuration proxies `/api` requests to the Node server on port 3000.

## API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| `GET` | `/api/health` | Checks ArcadeDB connectivity and initializes graph types/indexes |
| `GET` | `/api/clients/search?legalName=...` | Finds clients from the JSON index |
| `GET` | `/api/clients/:clientId` | Loads the latest JSON domain objects and verifies graph binding |
| `POST` | `/api/clients` | Writes a new JSON version, projects it to ArcadeDB, then verifies binding |
| `GET` | `/api/clients/:clientId/graph` | Reads graph nodes and edges from ArcadeDB for Cytoscape |

## Data and recovery behavior

The JSON objects are the canonical records; ArcadeDB is a governed projection. A write journal is created under `data/operations`. Files are prepared first, the ArcadeDB graph is changed in one SQL-script transaction, the graph is read back, and only then is `data/index.json` advanced. If graph persistence or binding verification fails, newly prepared JSON objects are removed and the operation is marked `ABORTED`.

This is intentionally a POC. Production hardening would add authentication, access control, encryption, a transactional outbox/object store, concurrent-write locking, signed audit records, policy-driven validation, backups, and observability.

## Configuration

Copy `.env.example` to `.env` and change values as needed. If you change `ARCADEDB_PASSWORD`, update the password in `docker-compose.yml` as well. Do not expose ports 2480 or 3000 outside a trusted local network without adding authentication and TLS.
