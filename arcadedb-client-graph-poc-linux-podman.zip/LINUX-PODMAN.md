# Linux and Podman deployment guide

This profile runs both the Node/React application and ArcadeDB as rootless containers. Both services bind to loopback by default. Use Nginx or an SSH tunnel for remote access; do not expose ArcadeDB directly to the network.

## 1. Server requirements

- A 64-bit systemd Linux distribution such as Ubuntu 24.04 LTS, Debian 12, RHEL 9, Rocky Linux 9, or AlmaLinux 9.
- At least 2 CPU cores, 4 GB RAM, and 10 GB free disk for a small POC.
- Podman 4.4+; Podman 5.x is recommended.
- A Compose provider: `podman-compose` or Docker Compose v2 available through `podman compose`.
- `curl`, `unzip`, and optionally Nginx.

Node.js is not required on the Linux host because the application is built and run inside its container.

## 2. Install Podman

### Ubuntu or Debian

```bash
sudo apt update
sudo apt install -y podman podman-compose curl unzip
podman --version
podman-compose --version
```

### RHEL, Rocky Linux, or AlmaLinux

```bash
sudo dnf install -y podman podman-compose curl unzip
podman --version
podman-compose --version
```

Do not run the application with `sudo podman`. Rootless Podman keeps the containers and volumes owned by the dedicated service account.

## 3. Create a dedicated service account

Run as a server administrator:

```bash
sudo useradd --create-home --shell /bin/bash clientgraph
sudo mkdir -p /opt/client-graph-poc
sudo chown clientgraph:clientgraph /opt/client-graph-poc
sudo loginctl enable-linger clientgraph
```

Copy and extract the ZIP into `/opt/client-graph-poc`, then assign ownership:

```bash
sudo unzip arcadedb-client-graph-poc-linux-podman.zip -d /opt/client-graph-poc
sudo chown -R clientgraph:clientgraph /opt/client-graph-poc
sudo -iu clientgraph
cd /opt/client-graph-poc
```

If extraction created an extra top-level directory, enter the directory containing `compose.linux.yaml`.

## 4. Configure the application

```bash
cp .env.example .env
chmod 600 .env
nano .env
```

At minimum, replace the demonstration password:

```env
ARCADEDB_PASSWORD=replace-with-a-long-random-password
```

Optional Linux settings can be appended or changed:

```env
APP_BIND_ADDRESS=127.0.0.1
APP_PORT=3000
ARCADEDB_BIND_ADDRESS=127.0.0.1
ARCADEDB_MEMORY=-Xms512M -Xmx512M
```

The password is consumed by ArcadeDB's declarative database creation and the Node API. If you change it after the database volume has been initialized, the stored ArcadeDB credentials do not automatically change.

## 5. Start with rootless Podman

```bash
chmod +x START-LINUX-PODMAN.sh STOP-LINUX-PODMAN.sh UPDATE-LINUX-PODMAN.sh INSTALL-LINUX-SERVICE.sh
./START-LINUX-PODMAN.sh
```

The first start downloads the images, builds the application, creates two named volumes, initializes `clientkg`, and verifies `/api/health`.

Check status and logs:

```bash
podman ps
podman compose -f compose.linux.yaml logs --tail=200
curl http://127.0.0.1:3000/api/health
```

If `podman compose` is unavailable, substitute `podman-compose` in manual commands. The supplied scripts detect either form automatically.

## 6. Test through an SSH tunnel

From your workstation:

```bash
ssh -L 3000:127.0.0.1:3000 your-user@your-linux-server
```

Open `http://localhost:3000` on the workstation. To inspect ArcadeDB Studio, also forward port 2480 and open `http://localhost:2480`:

```bash
ssh -L 3000:127.0.0.1:3000 -L 2480:127.0.0.1:2480 your-user@your-linux-server
```

## 7. Start automatically with systemd

As the `clientgraph` account:

```bash
cd /opt/client-graph-poc
./INSTALL-LINUX-SERVICE.sh
systemctl --user status client-graph-poc.service
```

The administrator must enable lingering once so the rootless user service starts during boot without an interactive login:

```bash
sudo loginctl enable-linger clientgraph
```

Useful commands:

```bash
systemctl --user restart client-graph-poc.service
systemctl --user stop client-graph-poc.service
journalctl --user -u client-graph-poc.service -f
```

## 8. Publish through Nginx

Keep port 3000 bound to `127.0.0.1`. On Ubuntu or Debian:

```bash
sudo apt install -y nginx
sudo cp deploy/nginx/client-graph-poc.conf /etc/nginx/sites-available/client-graph-poc
sudo nano /etc/nginx/sites-available/client-graph-poc
sudo ln -s /etc/nginx/sites-available/client-graph-poc /etc/nginx/sites-enabled/client-graph-poc
sudo nginx -t
sudo systemctl reload nginx
```

Replace `client-graph.example.com` with the real DNS name. On RHEL-family distributions, place the file at `/etc/nginx/conf.d/client-graph-poc.conf`.

On an SELinux-enforcing RHEL-family server, permit Nginx to connect to the loopback application port:

```bash
sudo setsebool -P httpd_can_network_connect 1
```

Example firewall rules:

```bash
# Ubuntu with UFW
sudo ufw allow 'Nginx Full'

# RHEL family with firewalld
sudo firewall-cmd --permanent --add-service=http
sudo firewall-cmd --permanent --add-service=https
sudo firewall-cmd --reload
```

Open only HTTP/HTTPS through the firewall. Do not open port 2480 publicly. Add TLS using your organisation's certificate process or Certbot before transmitting real client data.

## 9. Persistent data and backup

The deployment creates two Podman named volumes:

- `arcadedb-data`: ArcadeDB database files.
- `app-data`: versioned JSON objects, the client-name index, and operation journals.

Inspect the actual Compose-prefixed names:

```bash
podman volume ls
```

Use `podman volume inspect <name-from-the-list>` for either volume.

Back up both volumes together so the graph projection and authoritative JSON history remain aligned. Never use `podman compose down -v` unless you intentionally want to delete all POC data.

## 10. Update or stop

After replacing application source:

```bash
./UPDATE-LINUX-PODMAN.sh
```

Stop containers while retaining data:

```bash
./STOP-LINUX-PODMAN.sh
```

## Production boundary

This remains an architecture POC. Before handling real client information, add SSO, authorization, secrets management, TLS, encrypted storage, backups, monitoring, protected audit logs, concurrency control, vulnerability scanning, and a tested recovery procedure.
