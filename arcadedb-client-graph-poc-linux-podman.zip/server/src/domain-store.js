import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';

const DATA_ROOT = path.resolve(process.env.DOMAIN_DATA_DIR || 'data');
const OBJECT_ROOT = path.join(DATA_ROOT, 'domain-objects');
const OP_ROOT = path.join(DATA_ROOT, 'operations');
const INDEX_PATH = path.join(DATA_ROOT, 'index.json');

export function normalizeName(value) { return value.trim().replace(/\s+/g, ' ').toLocaleLowerCase('en'); }
export function slug(value) { return normalizeName(value).normalize('NFKD').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 70) || 'client'; }
export function stableStringify(value) {
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`;
  if (value && typeof value === 'object') return `{${Object.keys(value).sort().map(k => `${JSON.stringify(k)}:${stableStringify(value[k])}`).join(',')}}`;
  return JSON.stringify(value);
}
export const hashData = data => crypto.createHash('sha256').update(stableStringify(data)).digest('hex');

async function ensureStore() {
  await fs.mkdir(OBJECT_ROOT, { recursive: true }); await fs.mkdir(OP_ROOT, { recursive: true });
  try { await fs.access(INDEX_PATH); } catch { await fs.writeFile(INDEX_PATH, JSON.stringify({ formatVersion: 1, clients: {} }, null, 2)); }
}
export async function readIndex() { await ensureStore(); return JSON.parse(await fs.readFile(INDEX_PATH, 'utf8')); }
async function writeAtomic(target, value) { const temp = `${target}.${crypto.randomUUID()}.tmp`; await fs.writeFile(temp, JSON.stringify(value, null, 2)); await fs.rename(temp, target); }
export async function searchClients(query) {
  const index = await readIndex(); const normalized = normalizeName(query);
  const matches = Object.values(index.clients).filter(x => normalizeName(x.legalName).includes(normalized)).slice(0, 8);
  return { exact: index.clients[normalized] || null, suggestions: matches.map(({ clientId, legalName }) => ({ clientId, legalName })) };
}

function definitions(form) {
  return [
    ['ClientIdentity', { legalName: form.legalName.trim(), normalizedName: normalizeName(form.legalName) }, { legalName: '/data/legalName', normalizedName: '/data/normalizedName' }],
    ['EntityProfile', { legalName: form.legalName.trim(), countryOfIncorporation: form.countryOfIncorporation, incorporationNumber: form.incorporationNumber, legalForm: form.legalForm || null }, { legalName: '/data/legalName', countryOfIncorporation: '/data/countryOfIncorporation', incorporationNumber: '/data/incorporationNumber', legalForm: '/data/legalForm' }],
    ['RegisteredAddress', { addressType: 'REGISTERED', line1: form.addressLine1, line2: form.addressLine2 || null, city: form.city, region: form.region || null, postalCode: form.postalCode, country: form.addressCountry }, { addressType: '/data/addressType', line1: '/data/line1', line2: '/data/line2', city: '/data/city', region: '/data/region', postalCode: '/data/postalCode', country: '/data/country' }],
    ['IndustryClassification', { classifications: form.industryCodes }, { classifications: '/data/classifications' }]
  ];
}

export async function prepareVersion(form) {
  const index = await readIndex(); const key = normalizeName(form.legalName); const previous = index.clients[key];
  const clientId = previous?.clientId || `CLI-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
  const version = (previous?.latestVersion || 0) + 1; const now = new Date().toISOString(); const operationId = crypto.randomUUID();
  const objects = definitions(form).map(([domainObjectType, data, bindings]) => {
    const domainObjectId = `${clientId}:${domainObjectType}`;
    const kebab = domainObjectType.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();
    const fileName = `${slug(form.legalName)}__${kebab}__v${String(version).padStart(4, '0')}.json`;
    const envelope = { domainObjectId, domainObjectType, schemaVersion: '1.0', objectVersion: version, clientId, clientLegalName: form.legalName.trim(), recordedAt: now, status: 'ACTIVE', source: { system: 'POC_WEB_FORM', submittedBy: 'local-user' }, bindings, data };
    return { ...envelope, contentHash: hashData(data), fileName, domainObjectPath: `data/domain-objects/${fileName}` };
  });
  const operation = { operationId, status: 'PREPARED', clientId, legalName: form.legalName.trim(), version, createdAt: now, files: objects.map(x => x.fileName) };
  await writeAtomic(path.join(OP_ROOT, `${operationId}.json`), operation);
  for (const object of objects) { const { fileName, domainObjectPath, ...envelope } = object; await writeAtomic(path.join(OBJECT_ROOT, fileName), envelope); }
  return { index, key, previous, clientId, version, now, operation, objects, form };
}
export async function completeVersion(prepared) {
  const latest = Object.fromEntries(prepared.objects.map(x => [x.domainObjectType, { version: x.objectVersion, fileName: x.fileName, contentHash: x.contentHash }]));
  prepared.index.clients[prepared.key] = { clientId: prepared.clientId, legalName: prepared.form.legalName.trim(), latestVersion: prepared.version, updatedAt: prepared.now, latest };
  await writeAtomic(INDEX_PATH, prepared.index);
  await writeAtomic(path.join(OP_ROOT, `${prepared.operation.operationId}.json`), { ...prepared.operation, status: 'COMPLETED', completedAt: new Date().toISOString() });
}
export async function abortVersion(prepared, error) {
  for (const object of prepared.objects) await fs.rm(path.join(OBJECT_ROOT, object.fileName), { force: true });
  await writeAtomic(path.join(OP_ROOT, `${prepared.operation.operationId}.json`), { ...prepared.operation, status: 'ABORTED', error: String(error?.message || error), abortedAt: new Date().toISOString() });
}
export async function loadClient(clientId) {
  const index = await readIndex(); const entry = Object.values(index.clients).find(x => x.clientId === clientId); if (!entry) return null;
  const byType = {};
  for (const [type, latest] of Object.entries(entry.latest)) byType[type] = {
    ...JSON.parse(await fs.readFile(path.join(OBJECT_ROOT, latest.fileName), 'utf8')),
    fileName: latest.fileName,
    domainObjectPath: `data/domain-objects/${latest.fileName}`
  };
  const entity = byType.EntityProfile.data, address = byType.RegisteredAddress.data;
  return { clientId, latestVersion: entry.latestVersion, objects: byType, form: { legalName: entity.legalName, countryOfIncorporation: entity.countryOfIncorporation, incorporationNumber: entity.incorporationNumber, legalForm: entity.legalForm || '', addressLine1: address.line1, addressLine2: address.line2 || '', city: address.city, region: address.region || '', postalCode: address.postalCode, addressCountry: address.country, industryCodes: byType.IndustryClassification.data.classifications } };
}
