const baseUrl = process.env.ARCADEDB_URL || 'http://localhost:2480';
const database = process.env.ARCADEDB_DATABASE || 'clientkg';
const auth = Buffer.from(`${process.env.ARCADEDB_USER || 'root'}:${process.env.ARCADEDB_PASSWORD || 'playwithdata'}`).toString('base64');

async function command(command, params = {}, language = 'sql') {
  const response = await fetch(`${baseUrl}/api/v1/command/${database}`, { method: 'POST', headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ language, command, params }) });
  const text = await response.text(); let body; try { body = JSON.parse(text); } catch { body = { detail: text }; }
  if (!response.ok) throw new Error(`ArcadeDB ${response.status}: ${body.detail || body.error || text}`);
  return body.result || [];
}
export async function initializeGraph() {
  for (const type of ['ClientIdentity', 'EntityProfile', 'RegisteredAddress', 'IndustryClassification']) {
    await command(`CREATE VERTEX TYPE ${type} IF NOT EXISTS`);
    await command(`CREATE PROPERTY ${type}.graphKey IF NOT EXISTS STRING`);
  }
  await command('CREATE EDGE TYPE HAS_DOMAIN_OBJECT IF NOT EXISTS');
  for (const type of ['ClientIdentity', 'EntityProfile', 'RegisteredAddress', 'IndustryClassification']) await command(`CREATE INDEX IF NOT EXISTS ON ${type} (graphKey) UNIQUE`);
}

const graphFields = object => {
  const boundValues = Object.fromEntries(Object.keys(object.bindings).map(key => [
    `bound_${key}`,
    typeof object.data[key] === 'object' ? JSON.stringify(object.data[key]) : object.data[key]
  ]));
  return { graphKey: object.domainObjectId, clientId: object.clientId, label: object.domainObjectType === 'ClientIdentity' ? object.data.legalName : object.domainObjectType.replace(/([a-z])([A-Z])/g, '$1 $2'), domainObjectId: object.domainObjectId, domainObjectType: object.domainObjectType, objectVersion: object.objectVersion, domainObjectPath: object.domainObjectPath, contentHash: object.contentHash, dataJson: JSON.stringify(object.data), bindingsJson: JSON.stringify(object.bindings), recordedAt: object.recordedAt, ...boundValues };
};

export async function projectVersion(objects) {
  const lines = [];
  for (const object of objects) {
    const fields = graphFields(object); const setters = Object.keys(fields).map(k => `${k} = :${object.domainObjectType}_${k}`).join(', ');
    lines.push(`UPDATE ${object.domainObjectType} SET ${setters} UPSERT WHERE graphKey = :${object.domainObjectType}_graphKey;`);
  }
  const root = objects.find(x => x.domainObjectType === 'ClientIdentity');
  lines.push('DELETE FROM HAS_DOMAIN_OBJECT WHERE clientId = :edgeClientId;');
  for (const object of objects.filter(x => x !== root)) lines.push(`CREATE EDGE HAS_DOMAIN_OBJECT FROM (SELECT FROM ClientIdentity WHERE graphKey = :rootKey) TO (SELECT FROM ${object.domainObjectType} WHERE graphKey = :target_${object.domainObjectType}) SET clientId = :edgeClientId, sourceKey = :rootKey, targetKey = :target_${object.domainObjectType}, relationship = :rel_${object.domainObjectType};`);
  lines.push('RETURN true;');
  const params = { edgeClientId: root.clientId, rootKey: root.domainObjectId };
  for (const object of objects) { for (const [key, value] of Object.entries(graphFields(object))) params[`${object.domainObjectType}_${key}`] = value; if (object !== root) { params[`target_${object.domainObjectType}`] = object.domainObjectId; params[`rel_${object.domainObjectType}`] = object.domainObjectType === 'EntityProfile' ? 'HAS_ENTITY_PROFILE' : object.domainObjectType === 'RegisteredAddress' ? 'REGISTERED_AT' : 'CLASSIFIED_AS'; } }
  return command(lines.join('\n'), params, 'sqlscript');
}

export async function readGraph(clientId) {
  const vertices = [];
  for (const type of ['ClientIdentity', 'EntityProfile', 'RegisteredAddress', 'IndustryClassification']) vertices.push(...await command(`SELECT FROM ${type} WHERE clientId = :clientId`, { clientId }));
  const edges = await command('SELECT FROM HAS_DOMAIN_OBJECT WHERE clientId = :clientId', { clientId });
  return { nodes: vertices.map(v => ({ data: { id: v.graphKey, label: v.label, type: v.domainObjectType, objectVersion: v.objectVersion, contentHash: v.contentHash, domainObjectPath: v.domainObjectPath, payload: JSON.parse(v.dataJson || '{}') } })), edges: edges.map((e, i) => ({ data: { id: e['@rid'] || `edge-${i}`, source: e.sourceKey || vertices[0]?.graphKey, target: e.targetKey || vertices[i + 1]?.graphKey, label: e.relationship } })) };
}

export async function verifyBindings(objects) {
  const result = [];
  for (const object of objects) {
    const rows = await command(`SELECT FROM ${object.domainObjectType} WHERE graphKey = :graphKey`, { graphKey: object.domainObjectId }); const graph = rows[0];
    const fieldBindingsMatch = graph && Object.keys(object.bindings).every(key => graph[`bound_${key}`] === (typeof object.data[key] === 'object' ? JSON.stringify(object.data[key]) : object.data[key]));
    const status = graph && graph.objectVersion === object.objectVersion && graph.contentHash === object.contentHash && graph.dataJson === JSON.stringify(object.data) && graph.bindingsJson === JSON.stringify(object.bindings) && fieldBindingsMatch ? 'BOUND' : 'DRIFT';
    result.push({ domainObjectType: object.domainObjectType, fileName: object.fileName, status });
  }
  return { status: result.every(x => x.status === 'BOUND') ? 'BOUND' : 'DRIFT', objects: result };
}
