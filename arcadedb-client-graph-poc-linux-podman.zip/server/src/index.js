import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { z } from 'zod';
import { abortVersion, completeVersion, loadClient, prepareVersion, searchClients } from './domain-store.js';
import { initializeGraph, projectVersion, readGraph, verifyBindings } from './arcadedb.js';

const industry = z.object({ system: z.string().min(1), code: z.string().min(1), description: z.string().min(1) });
const clientSchema = z.object({ legalName: z.string().min(2), countryOfIncorporation: z.string().min(2), incorporationNumber: z.string().min(1), legalForm: z.string(), addressLine1: z.string().min(2), addressLine2: z.string(), city: z.string().min(1), region: z.string(), postalCode: z.string().min(1), addressCountry: z.string().min(2), industryCodes: z.array(industry).min(1) });
const app = express(); app.use(cors()); app.use(express.json({ limit: '1mb' }));

app.get('/api/health', async (_req, res) => { try { await initializeGraph(); res.json({ status: 'ok', database: process.env.ARCADEDB_DATABASE || 'clientkg' }); } catch (error) { res.status(503).json({ status: 'error', error: error.message }); } });
app.get('/api/clients/search', async (req, res) => { try { res.json(await searchClients(String(req.query.legalName || ''))); } catch (error) { res.status(500).json({ error: error.message }); } });
app.get('/api/clients/:clientId', async (req, res) => {
  try {
    const client = await loadClient(req.params.clientId); if (!client) return res.status(404).json({ error: 'Client not found' });
    let binding;
    try { binding = await verifyBindings(Object.values(client.objects)); }
    catch (error) { binding = { status: 'UNAVAILABLE', error: error.message, objects: Object.values(client.objects).map(x => ({ domainObjectType: x.domainObjectType, fileName: x.fileName, status: 'UNAVAILABLE' })) }; }
    res.json({ ...client, binding });
  } catch (error) { res.status(500).json({ error: error.message }); }
});
app.get('/api/clients/:clientId/graph', async (req, res) => { try { res.json(await readGraph(req.params.clientId)); } catch (error) { res.status(503).json({ error: error.message }); } });
app.post('/api/clients', async (req, res) => {
  const parsed = clientSchema.safeParse(req.body); if (!parsed.success) return res.status(400).json({ error: 'Validation failed', issues: parsed.error.issues });
  let prepared;
  try { await initializeGraph(); prepared = await prepareVersion(parsed.data); await projectVersion(prepared.objects); const binding = await verifyBindings(prepared.objects); if (binding.status !== 'BOUND') throw new Error('Strict binding verification failed; index was not advanced.'); await completeVersion(prepared); res.status(201).json({ clientId: prepared.clientId, latestVersion: prepared.version, form: parsed.data, binding }); }
  catch (error) { if (prepared) await abortVersion(prepared, error); res.status(503).json({ error: error.message }); }
});

const here = path.dirname(fileURLToPath(import.meta.url)); const dist = path.resolve(here, '../../client/dist');
app.use(express.static(dist)); app.get('*all', (_req, res) => res.sendFile(path.join(dist, 'index.html')));
const port = Number(process.env.PORT || 3000); app.listen(port, () => console.log(`Client Graph POC: http://localhost:${port}`));
